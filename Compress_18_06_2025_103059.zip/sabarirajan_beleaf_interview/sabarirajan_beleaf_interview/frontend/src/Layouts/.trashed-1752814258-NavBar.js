import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ApiRequest } from "../utils/ApiRequest";
import { useToast } from "../context/ToastProvider";

const Navbar = ({ fetchData }) => {
  const { showCustomToast } = useToast();
  const navigate = useNavigate();

  const loadDemoAllUSerData = async () => {
    try {
      const params = {
        url: "/load-all-user",
        method: "POST",
      };
      const response = await ApiRequest(params);
      if (response.status) {
        showCustomToast(response.message, "success");
        fetchData();
      }
    } catch (error) {
      showCustomToast("Something went wrong!", "danger");
    }
  };
  const styles = {
    navbar: {
      display: "flex",
      alignItems: "center",
      padding: "10px 20px",
      backgroundColor: "#f5f5f5",
      boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
    },
    leftButton: {
      padding: "8px 16px",
      backgroundColor: "#4caf50",
      color: "#fff",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer",
    },
    spacer: {
      flexGrow: 1,
    },
    rightButton: {
      padding: "8px 16px",
      backgroundColor: "#2196f3",
      color: "#fff",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer",
    },
  };
  return (
    <nav style={styles.navbar}>
      <button style={styles.leftButton} onClick={() => loadDemoAllUSerData()}>
        Load User
      </button>

      <div style={styles.spacer}></div>

      <button style={styles.rightButton} onClick={() => navigate("/add-user")}>
        Add User
      </button>
    </nav>
  );
};

export default Navbar;
