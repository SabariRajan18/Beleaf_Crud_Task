import { body, validationResult } from "express-validator";

export const validateUser = [
  body("name").exists({ checkFalsy: true }).withMessage("Name is required"),
  body("username")
    .exists({ checkFalsy: true })
    .withMessage("Username is required"),
  body("email")
    .exists({ checkFalsy: true })
    .withMessage("Email is required")
    .bail()
    .isEmail()
    .withMessage("Invalid email format"),
  body("phone")
    .exists({ checkFalsy: true })
    .withMessage("Phone is required")
    .bail()
    .isMobilePhone()
    .withMessage("Invalid phone number"),
  body("company.name")
    .exists({ checkFalsy: true })
    .withMessage("Company name is required"),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({
        status: false,
        errors: errors.array().map((e) => ({
          field: e.param,
          message: e.msg,
        })),
      });
    }
    next();
  },
];
