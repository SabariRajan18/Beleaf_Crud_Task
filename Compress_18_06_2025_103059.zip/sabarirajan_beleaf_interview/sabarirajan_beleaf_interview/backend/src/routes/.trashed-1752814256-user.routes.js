import express from "express";
import userControllers from "../controllers/user.controllers.js";
import { validateUser } from "../middlewares/user.validation.js";
const router = express.Router();

router.get("/get-all-users", userControllers.getAllUsers);
router.get("/get-user/:id", userControllers.getUserById);
router.post("/create-user", validateUser, userControllers.createUser);
router.put("/update-user/:id", validateUser, userControllers.updateUser);
router.delete("/delete-user/:id", userControllers.deleteUser);

// load the demo data
router.post("/load-all-user", userControllers.loadAllUser);
export default router;
