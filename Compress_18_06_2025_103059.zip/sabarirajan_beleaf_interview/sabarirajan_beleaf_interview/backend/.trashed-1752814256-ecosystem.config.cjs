module.exports = {
  apps: [
    {
      name: "backend-crud-task",
      script: "src/server.js",
      watch: true,
      autorestart: true,
      error_file: './src/pm2/err.log',
      out_file: './src/pm2/out.log',   
      env: {
        NODE_ENV: "development",
      },
    },
  ],
};
